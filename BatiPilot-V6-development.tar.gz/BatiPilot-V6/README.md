# BatiPilot V6 - patch de développement
Ce package est construit à partir des sources V5.4/V5.5 transmises. Il ajoute le socle V6 vérifiable : vrai composant Gantt temporel, synthèse finance, modèles Prisma marchés/avenants/situations, documents versionnés/générations, notifications, routes API associées et CSS.

## Important
Le schéma fourni est un ADDON : fusionner ses modèles et relations dans le schema.prisma existant avant `prisma format`. Les API Contract nécessitent le client Prisma régénéré.
La GED binaire et la conversion DOCX/PDF nécessitent un fournisseur de stockage et de conversion choisi par l'exploitant. Elles ne sont pas simulées dans ce patch.

## Intégration UI
Dans ProjectWorkspace.tsx :
- importer `ProjectGanttV6` puis remplacer le rendu interne de l'onglet Gantt par `<ProjectGanttV6 rows={planning}/>`.
- importer `FinanceV6` puis remplacer le Simple de l'onglet finance par `<FinanceV6 budgets={p.budgets}/>`.
- ajouter le contenu de V6_STYLE_ADDON.css à app/style.css.

## Validation
1. `npx.cmd prisma format`
2. `npx.cmd prisma generate`
3. sauvegarde DB
4. générer/revoir une migration Prisma
5. `npm.cmd run build`
6. `npm.cmd test`
7. push `feature/batipilot-v6`, valider Preview Vercel, puis fusionner main.
