$ErrorActionPreference='Stop'
$root='C:\BatiPilot-Full'
Set-Location $root
Write-Host '1/5 Sauvegarde Git...' -ForegroundColor Cyan
git add .
git commit -m "Backup avant BatiPilot V6" 2>$null
Write-Host '2/5 Création branche V6...' -ForegroundColor Cyan
git checkout -B feature/batipilot-v6
Write-Host '3/5 Copie manuelle requise des fichiers du package dans le projet.' -ForegroundColor Yellow
Write-Host 'Le fichier V6_SCHEMA_ADDON.prisma doit être fusionné dans prisma/schema.prisma, pas copié tel quel.' -ForegroundColor Yellow
Write-Host '4/5 Après fusion du schema: npx.cmd prisma format ; npx.cmd prisma generate ; npm.cmd run build' -ForegroundColor Cyan
Write-Host '5/5 Ne lancez prisma db push qu après sauvegarde et validation du diff SQL.' -ForegroundColor Red
